// ================== Exercises 1-10 ==================
let colorBtn = document.getElementById("colorBtn");
// تغيير لون الخلفية بعدة ألوان
let colors = ["lightblue", "lightgray", "beige", "whitesmoke", "silver"];
let index = 0;

colorBtn.addEventListener("click", () => {
  document.body.style.backgroundColor = colors[index];
  index = (index + 1) % colors.length; // يتغير اللون في كل ضغطة
});


let clickBtn = document.getElementById("clickBtn");
clickBtn.addEventListener("click", () => document.getElementById("sampleText").textContent = "تم الضغط!");

let inputBox = document.getElementById("inputBox");
inputBox.addEventListener("input", () => document.getElementById("display").textContent = inputBox.value);

let highlightPara = document.querySelector(".highlight");
highlightPara.style.color = "red";

let container = document.getElementById("container");
container.style.backgroundColor = "lightgray";

let listItems = document.querySelectorAll("ul li");
listItems.forEach(li => {
  li.style.fontWeight = "bold";
  li.addEventListener("mouseover", () => li.style.color = "blue");
  li.addEventListener("mouseout", () => li.style.color = "black");
});

document.querySelector("h1").textContent = "DOM Practice Lab - Updated";
document.querySelectorAll("p")[2].style.color = "green";

// ================== Exercises 11-20 ==================
let newPara = document.createElement("p");
newPara.textContent = "هذه فقرة جديدة تم إنشاؤها ديناميكياً.";
document.body.appendChild(newPara);

let newSpan = document.createElement("span");
newSpan.textContent = " (تمت الإضافة داخل div)";
container.appendChild(newSpan);

let ul = document.querySelector("ul");
let li4 = document.createElement("li");
li4.textContent = "List Item 4";
ul.appendChild(li4);

let li0 = document.createElement("li");
li0.textContent = "Item 0";
ul.insertBefore(li0, ul.firstChild);

let newButton = document.createElement("button");
newButton.textContent = "اضغطني";
document.body.appendChild(newButton);
newButton.addEventListener("click", () => alert("تم الضغط على الزر الجديد!"));

let img = document.createElement("img");
img.src = "https://via.placeholder.com/100";
img.alt = "Placeholder Image";
document.body.appendChild(img);

let link = document.createElement("a");
link.href = "https://www.google.com";
link.textContent = "اذهب إلى Google";
link.target = "_blank";
document.body.appendChild(link);

let fruits = ["تفاح", "موز", "برتقال"];
let fruitList = document.createElement("ul");
fruits.forEach(fruit => {
  let li = document.createElement("li");
  li.textContent = fruit;
  fruitList.appendChild(li);
});
document.body.appendChild(fruitList);

let clonedPara = newPara.cloneNode(true);
document.body.appendChild(clonedPara);

let newDiv = document.createElement("div");
newDiv.style.border = "1px solid black";
newDiv.style.padding = "5px";
let innerP = document.createElement("p");
innerP.textContent = "هذه فقرة داخل div جديد";
newDiv.appendChild(innerP);
document.body.appendChild(newDiv);

// ================== Exercises 21-30 ==================
document.querySelectorAll("p").forEach(p => {
  p.addEventListener("click", () => p.style.color = "orange");
});

container.addEventListener("mouseover", () => container.style.backgroundColor = "lightgreen");
container.addEventListener("mouseout", () => container.style.backgroundColor = "lightgray");

let alertBtn = document.createElement("button");
alertBtn.textContent = "عرض رسالة";
document.body.appendChild(alertBtn);
alertBtn.addEventListener("click", () => alert("مرحبا!"));

let titleInput = document.createElement("input");
titleInput.placeholder = "غير العنوان هنا";
document.body.appendChild(titleInput);
titleInput.addEventListener("input", () => document.querySelector("h1").textContent = titleInput.value);

let addParaInput = document.createElement("input");
addParaInput.placeholder = "أضف فقرة جديدة";
document.body.appendChild(addParaInput);
addParaInput.addEventListener("keypress", e => {
  if(e.key === "Enter") {
    let p = document.createElement("p");
    p.textContent = addParaInput.value;
    document.body.appendChild(p);
    addParaInput.value = "";
  }
});

let removeLastBtn = document.createElement("button");
removeLastBtn.textContent = "إزالة آخر عنصر";
document.body.appendChild(removeLastBtn);
removeLastBtn.addEventListener("click", () => {
  let items = ul.querySelectorAll("li");
  if(items.length) items[items.length-1].remove();
});

let changeListBtn = document.createElement("button");
changeListBtn.textContent = "تغيير كل عناصر القائمة";
document.body.appendChild(changeListBtn);
changeListBtn.addEventListener("click", () => {
  ul.querySelectorAll("li").forEach((li, i) => li.textContent = `عنصر جديد ${i+1}`);
});

let colorParasBtn = document.createElement("button");
colorParasBtn.textContent = "تلوين الفقرات";
document.body.appendChild(colorParasBtn);
colorParasBtn.addEventListener("click", () => {
  document.querySelectorAll("p").forEach(p => p.style.color = "purple");
});

let cloneBtn = document.createElement("button");
cloneBtn.textContent = "نسخ الفقرة الأولى";
document.body.appendChild(cloneBtn);
cloneBtn.addEventListener("click", () => {
  let firstP = document.querySelector("p");
  let copy = firstP.cloneNode(true);
  document.body.appendChild(copy);
});

let changeSpanBtn = document.createElement("button");
changeSpanBtn.textContent = "تغيير نص span";
document.body.appendChild(changeSpanBtn);
changeSpanBtn.addEventListener("click", () => {
  document.getElementById("sampleText").textContent = "تم التغيير!";
});

// ================== Exercises 31-40 ==================
let cities = ["عمان", "إربد", "الزرقاء"];
let cityList = document.createElement("ul");
cities.forEach(city => {
  let li = document.createElement("li");
  li.textContent = city;
  cityList.appendChild(li);
});
document.body.appendChild(cityList);

let removeFirstCityBtn = document.createElement("button");
removeFirstCityBtn.textContent = "إزالة أول مدينة";
document.body.appendChild(removeFirstCityBtn);
removeFirstCityBtn.addEventListener("click", () => cityList.querySelector("li")?.remove());

let liNew = document.createElement("li");
liNew.textContent = "مدينة جديدة";
cityList.insertBefore(liNew, cityList.querySelector("li"));

cityList.querySelectorAll("li").forEach(li => {
  li.addEventListener("mouseover", () => li.style.color = "red");
  li.addEventListener("mouseout", () => li.style.color = "black");
});

let addCityBtn = document.createElement("button");
addCityBtn.textContent = "أضف مدينة جديدة";
document.body.appendChild(addCityBtn);
addCityBtn.addEventListener("click", () => {
  let newLi = document.createElement("li");
  newLi.textContent = `مدينة ${cityList.children.length + 1}`;
  cityList.appendChild(newLi);
});

let hideBtn = document.createElement("button");
hideBtn.textContent = "إخفاء الفقرة الأولى";
document.body.appendChild(hideBtn);
hideBtn.addEventListener("click", () => {
  let firstP = document.querySelector("p");
  if(firstP) firstP.style.display = "none";
});

let showBtn = document.createElement("button");
showBtn.textContent = "إظهار الفقرة الأولى";
document.body.appendChild(showBtn);
showBtn.addEventListener("click", () => {
  let firstP = document.querySelector("p");
  if(firstP) firstP.style.display = "block";
});

let repeatBtn = document.createElement("button");
repeatBtn.textContent = "كرر النص داخل div";
document.body.appendChild(repeatBtn);
repeatBtn.addEventListener("click", () => {
  container.textContent += " تم التكرار!";
});

let bgParasBtn = document.createElement("button");
bgParasBtn.textContent = "تغيير خلفية الفقرات";
document.body.appendChild(bgParasBtn);
bgParasBtn.addEventListener("click", () => {
  document.querySelectorAll("p").forEach(p => p.style.backgroundColor = "lightyellow");
});

let clearDivBtn = document.createElement("button");
clearDivBtn.textContent = "مسح نصوص div";
document.body.appendChild(clearDivBtn);
clearDivBtn.addEventListener("click", () => {
  container.textContent = "";
});
