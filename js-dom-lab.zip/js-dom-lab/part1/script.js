// ================== Exercises 1-10 ==================
let colorBtn = document.getElementById("colorBtn");
colorBtn.addEventListener("click", () => document.body.style.backgroundColor = "lightblue");

let clickBtn = document.getElementById("clickBtn");
clickBtn.addEventListener("click", () => document.getElementById("sampleText").textContent = "تم الضغط!");

let inputBox = document.getElementById("inputBox");
inputBox.addEventListener("input", () => document.getElementById("display").textContent = inputBox.value);

let highlightPara = document.querySelector(".highlight");
highlightPara.style.color = "red";
let container = document.getElementById("container");
container.style.backgroundColor = "lightgray";

let listItems = document.querySelectorAll("ul li");
listItems.forEach(li => {
  li.style.fontWeight = "bold";
  li.addEventListener("mouseover", () => li.style.color = "blue");
  li.addEventListener("mouseout", () => li.style.color = "black");
});

highlightPara.classList.add("new-class");
highlightPara.classList.remove("new-class");

document.querySelector("h1").textContent = "DOM Practice Lab - Updated";
document.querySelectorAll("p")[2].style.color = "green";

// ================== Exercises 11-20 ==================
let newPara = document.createElement("p");
newPara.textContent = "هذه فقرة جديدة تم إنشاؤها ديناميكياً.";
document.body.appendChild(newPara);

let newSpan = document.createElement("span");
newSpan.textContent = " (تمت الإضافة داخل div)";
container.appendChild(newSpan);

let ul = document.getElementById("mainList");
let li4 = document.createElement("li");
li4.textContent = "List Item 4";
ul.appendChild(li4);

let li0 = document.createElement("li");
li0.textContent = "Item 0";
ul.insertBefore(li0, ul.firstChild);

let newButton = document.createElement("button");
newButton.textContent = "اضغطني";
document.body.appendChild(newButton);
newButton.addEventListener("click", () => alert("تم الضغط على الزر الجديد!"));

let img = document.createElement("img");
img.src = "https://via.placeholder.com/100";
img.alt = "Placeholder Image";
document.body.appendChild(img);

let link = document.createElement("a");
link.href = "https://www.google.com";
link.textContent = "اذهب إلى Google";
link.target = "_blank";
document.body.appendChild(link);

let fruits = ["تفاح", "موز", "برتقال"];
let fruitList = document.createElement("ul");
fruits.forEach(fruit => {
  let li = document.createElement("li");
  li.textContent = fruit;
  fruitList.appendChild(li);
});
document.body.appendChild(fruitList);

let clonedPara = newPara.cloneNode(true);
document.body.appendChild(clonedPara);

let newDiv = document.createElement("div");
newDiv.style.border = "1px solid black";
newDiv.style.padding = "5px";
let innerP = document.createElement("p");
innerP.textContent = "هذه فقرة داخل div جديد";
newDiv.appendChild(innerP);
document.body.appendChild(newDiv);

// ================== Exercises 21-30 ==================
// Mini 21: click لتغيير لون الفقرة
document.querySelectorAll("p").forEach(p => {
  p.addEventListener("click", () => p.style.color = "orange");
});

// Mini 22: hover لتغيير خلفية div
container.addEventListener("mouseover", () => container.style.backgroundColor = "lightgreen");
container.addEventListener("mouseout", () => container.style.backgroundColor = "lightgray");

// Mini 23: زر جديد يظهر رسالة عند الضغط
let alertBtn = document.createElement("button");
alertBtn.textContent = "عرض رسالة";
document.body.appendChild(alertBtn);
alertBtn.addEventListener("click", () => alert("مرحبا!"));

// Mini 24: إدخال نص لتغيير عنوان
let titleInput = document.createElement("input");
titleInput.placeholder = "غير العنوان هنا";
document.body.appendChild(titleInput);
titleInput.addEventListener("input", () => document.querySelector("h1").textContent = titleInput.value);

// Mini 25: إدخال نص يضيف فقرة جديدة
let addParaInput = document.createElement("input");
addParaInput.placeholder = "أضف فقرة جديدة";
document.body.appendChild(addParaInput);
addParaInput.addEventListener("keypress", e => {
  if(e.key === "Enter") {
    let p = document.createElement("p");
    p.textContent = addParaInput.value;
    document.body.appendChild(p);
    addParaInput.value = "";
  }
});

// Mini 26: إزالة آخر عنصر في القائمة
let removeLastBtn = document.createElement("button");
removeLastBtn.textContent = "إزالة آخر عنصر";
document.body.appendChild(removeLastBtn);
removeLastBtn.addEventListener("click", () => {
  let items = ul.querySelectorAll("li");
  if(items.length) items[items.length-1].remove();
});

// Mini 27: تغيير كل عناصر القائمة
let changeListBtn = document.createElement("button");
changeListBtn.textContent = "تغيير كل عناصر القائمة";
document.body.appendChild(changeListBtn);
changeListBtn.addEventListener("click", () => {
  ul.querySelectorAll("li").forEach((li, i) => li.textContent = `عنصر جديد ${i+1}`);
});

// Mini 28: تلوين كل الفقرات عند الضغط
let colorParasBtn = document.createElement("button");
colorParasBtn.textContent = "تلوين الفقرات";
document.body.appendChild(colorParasBtn);
colorParasBtn.addEventListener("click", () => {
  document.querySelectorAll("p").forEach(p => p.style.color = "purple");
});

// Mini 29: نسخ عنصر عند الضغط
let cloneBtn = document.createElement("button");
cloneBtn.textContent = "نسخ الفقرة الأولى";
document.body.appendChild(cloneBtn);
cloneBtn.addEventListener("click", () => {
  let firstP = document.querySelector("p");
  let copy = firstP.cloneNode(true);
  document.body.appendChild(copy);
});

// Mini 30: تغيير نص العنصر span
let changeSpanBtn = document.createElement("button");
changeSpanBtn.textContent = "تغيير نص span";
document.body.appendChild(changeSpanBtn);
changeSpanBtn.addEventListener("click", () => {
  document.getElementById("sampleText").textContent = "تم التغيير!";
});

// ================== Exercises 31-40 ==================
// Mini 31: إنشاء قائمة جديدة من مصفوفة
let cities = ["عمان", "إربد", "الزرقاء"];
let cityList = document.createElement("ul");
cities.forEach(city => {
  let li = document.createElement("li");
  li.textContent = city;
  cityList.appendChild(li);
});
document.body.appendChild(cityList);

// Mini 32: حذف عنصر محدد
let removeFirstCityBtn = document.createElement("button");
removeFirstCityBtn.textContent = "إزالة أول مدينة";
document.body.appendChild(removeFirstCityBtn);
removeFirstCityBtn.addEventListener("click", () => cityList.querySelector("li")?.remove());

// Mini 33: إدراج عنصر قبل عنصر محدد
let liNew = document.createElement("li");
liNew.textContent = "مدينة جديدة";
cityList.insertBefore(liNew, cityList.querySelector("li"));

// Mini 34: تغيير لون عناصر القائمة عند hover
cityList.querySelectorAll("li").forEach(li => {
  li.addEventListener("mouseover", () => li.style.color = "red");
  li.addEventListener("mouseout", () =>
